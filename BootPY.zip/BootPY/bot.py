﻿import discord
from discord.ext import commands
from discord.ext import tasks
from discord.utils import get
import os
import asyncio
import time
import random
import requests
import json
from aiohttp import request
from discord.ext.commands import Cog, BucketType
from datetime import datetime
from os import system
import os
import collections
import discord
from discord.ext import commands
import requests
from datetime import datetime
import subprocess
import time
import json
import random
import datetime
import random
import string
from discord.ext.commands import has_permissions
from discord.ext.commands import has_role
import discord
from discord.ext import commands
from discord.ext.commands import Bot
import asyncio
from discord.utils import get
import os
import collections
import discord
from discord.ext import commands
import requests
from datetime import datetime
import subprocess
import time
import json
import datetime
import random
import string
from discord.ext.commands import has_permissions
from discord.ext.commands import has_role
import asyncio
import collections
import discord
from discord.ext import commands
from datetime import datetime
import datetime
import pymongo
from discord import User

#--- Variables ---#

blacklist = requests.get('https://pastebin.com/???').text
TOKEN = "" # <<< DISCORD TOKEN GOES HERE
PREFIX = "!" # <<< PREFIX
client = commands.Bot(command_prefix = PREFIX)
client.remove_command('help')
reds = 0x9700FF

#--- STARTUP ---#

@client.event
async def on_ready():
	await client.change_presence(status=discord.Status.online, activity=discord.Game(name='//help | We Are PortLords'))
	print("Boot.PY Online")


#--- WELCOME MSG ---#

@client.event
async def on_member_join(member):
	channel = discord.utils.get(member.guild.channels, name="ʙᴏᴛsᴘᴀᴍ")
	await channel.send(f"Welcome to ZootBot {member.mention}... From PortLords w/ Love")
	embed = discord.Embed(color=reds)
	embed.set_thumbnail(url=f"{member.avatar_url}")
	embed.add_field(name="Display Name:", value=f"```{member.display_name}```", inline=False)
	embed.add_field(name="Account Creation:", value=member.created_at.strftime("```%a, %#d %B %Y, %I:%M %p UTC```"), inline=False)
	embed.add_field(name="Member Since:", value=member.joined_at.strftime("```%a, %#d %B %Y, %I:%M %p UTC```"), inline=False)
	await channel.send(embed=embed)
	role = discord.utils.get(member.guild.roles, name="") # <<< ROLE REQUIRED TO RUN THE BOT
	await member.add_roles(role)

#--- HELP MENU ---#

@client.command()
@has_role("") # <<< ROLE REQUIRED TO RUN THE BOT
@commands.guild_only()
async def help(ctx):
	await ctx.message.delete()
	embed = discord.Embed(color=reds, title="Boot.PY Help Menu", timestamp=ctx.message.created_at)
	embed.add_field(name="User Commands", value=f"""```
{PREFIX}help
{PREFIX}tos
{PREFIX}prices
{PREFIX}purchase
{PREFIX}ticket
{PREFIX}links
```""", inline=True)
	embed.add_field(name="Client Commands", value=f"""```
{PREFIX}methods
{PREFIX}attack
{PREFIX}faq
```""", inline=True)
	embed.add_field(name="Network Tools", value=f"""```
{PREFIX}pscan
{PREFIX}geo
{PREFIX}ping
{PREFIX}paping
```""", inline=True)
	embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar_url)
	await ctx.send(embed=embed)

#--- MOD MENU ---#

@client.command()
@has_role("卐")
@commands.guild_only()
async def helpmod(ctx):
    await ctx.message.delete()
    embed = discord.Embed(color=reds, title="Boot.PY Help Menu", timestamp=ctx.message.created_at)
    embed.add_field(name="Moderation Commands", value=f"""```
{PREFIX}add
{PREFIX}ban
{PREFIX}clear
{PREFIX}mute
{PREFIX}kick
{PREFIX}nuke
{PREFIX}remove
{PREFIX}unmute
```""", inline=True)
    embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar_url)
    await ctx.send(embed=embed)

#--- PRICES ---#

@client.command()
@commands.guild_only()
async def prices(ctx):
	await ctx.message.delete()
	embed = discord.Embed(color=reds, title="Boot.PY Purchase Menu", timestamp=ctx.message.created_at)
	embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/893798872202248232/893817597915697172/2644_earthblack.gif")
	embed.add_field(name="Payment Methods", value="""```
**CASHAPP:** `$Cashtag` **|** `$Cashtag`
**PAYPAL:** `Paypal Link`
```""", inline=True)
	embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar_url)
	await ctx.send(embed=embed)

#--- Purchase ---#

@client.command()
@commands.guild_only()
async def ticket(ctx):
	await ctx.message.delete()
	embed = discord.Embed(color=reds, title="Boot.PY Purchase Menu", timestamp=ctx.message.created_at)
	embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/893798872202248232/893817597915697172/2644_earthblack.gif")
	embed.add_field(name="How To Purchase", value="""

**[1]** `Create A Ticket`
**[2]** `While your waiting on staff to respond, send the following info:` 
**[3]** `Desired Payment Method`
**[4]** `Service you would like to purchase`
**[5]** `Duration / Specifics of desired service`
**[6]** `A staff member will reply with further instructions`""", inline=True)
	embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar_url)
	await ctx.send(embed=embed)

#--- Links ---#

@client.command()
@commands.guild_only()
async def links(ctx):
	await ctx.message.delete()
	embed = discord.Embed(color=reds, title="Follow us on Social Media", timestamp=ctx.message.created_at)
	embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/893798872202248232/893817597915697172/2644_earthblack.gif")
	embed.add_field(name="Contact Us", value="""
**Instagram:** `https://instagram.com/portlordss`
**Discord:** `https://discord.gg/cmugYuMH85`
**Guilded:** `https://www.guilded.gg/i/pYr13roE`
**Telegram:** `https://T.me/PortLordz`
**Coming Soon:** `https://PortLords.com`
""", inline=True)
	embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar_url)
	await ctx.send(embed=embed)

#--- Credits ---#

@client.command()
@has_role("Verified")
@commands.guild_only()
async def credits(ctx):
	await ctx.message.delete()
	embed = discord.Embed(color=reds, title="Developer Credits", timestamp=ctx.message.created_at)
	embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/893798872202248232/893817597915697172/2644_earthblack.gif")
	embed.add_field(name="Owner / Developer", value="""
[+] INFO 
- **Boot.PY** *is a Discord* ||Stress|| *Bot, written in* `.js`

[+] Owner [+]
- **PortLords**

[+] Developer [+]
- **Herawen**

[+] Powered By [+]
- **PortLords** *Home Holder API*
""", inline=True)
	embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar_url)
	await ctx.send(embed=embed)

#--- GEO ---#

@client.command()
@commands.guild_only()
async def geo(ctx, host):
	await ctx.message.delete()
	r = requests.get(f"https://ipinfo.io/{host}/json?token=ea26dd751430f6")
	res = r.json()
	embed = discord.Embed(color=reds, timestamp=ctx.message.created_at)
	embed.add_field(name= "IP", value= res['||ip||'], inline=True)
	embed.add_field(name="Hostname", value= res['hostname'], inline=True)
	embed.add_field(name="City", value= res['city'], inline=True)
	embed.add_field(name="Region", value= res['region'], inline=True)
	embed.add_field(name="Country", value= res['country'], inline=True)
	embed.add_field(name="Geo-Location", value= res['loc'], inline=True)
	embed.add_field(name="Organization", value= res['org'], inline=True)
	embed.add_field(name="Postal", value= res['postal'], inline=True)
	embed.add_field(name="Timezone", value= res['timezone'], inline=True)
	embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/893798872202248232/893817597915697172/2644_earthblack.gif")
	embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar_url)
	await ctx.send(embed=embed)

#--- ATTACK ---#

@client.command()
@has_role("卐")
@commands.guild_only()
async def hta(ctx):
	await ctx.message.delete()
	embed = discord.Embed(color=reds, title="Stress Testing w/ Boot.PY", timestamp=ctx.message.created_at)
	embed.add_field(name="Use This Format: || //attack <host> <port> <time> <method> <pps> ||", inline=True)
	embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/893798872202248232/893817597915697172/2644_earthblack.gif")
	embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar_url)
	await ctx.send(embed=embed)

#--- TOS ---#

@client.command()
@commands.guild_only()
async def tos(ctx):
	await ctx.message.delete()
	embed = discord.Embed(color=reds, title="Boot.PY Terms Of Service", timestamp=ctx.message.created_at)
	embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/778141356962349126/785620077604372551/png-transparent-computer-icons-terms-of-service-rental-agreement-contract-handshake_1.png")
	embed.add_field(name="Please Read / Agree to Our T.O.S.", value="""
---- Root Bot Rules ----
•  No Refunds
•  No Spamming Attacks
•  No Sharing Accounts
•  No .GOV / Federal Websites
•  For Educational Purposes Only
---------------------------------------
•  24 Hour Hold Time
•  Fast Sending API
•  Up To 10GBps
""", inline=True)
	embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar_url)
	await ctx.send(embed=embed)

#--- PING ---#

@client.command()
@commands.guild_only()
async def ping(ctx, host):
	await ctx.message.delete()
	embed = discord.Embed(color=reds, title=f'Pinging {host} (Ping Sent, Please Wait For Response)', timestamp=ctx.message.created_at)
	await ctx.send(embed=embed)
	response = os.system(f"ping {host} -n 3")
	if response == 0:
		embed = discord.Embed(color=reds, title=f'{host} is Online ✅')
		await ctx.send(embed=embed)
	else:
		embed = discord.Embed(color=reds, title=f'{host} Host is Offline ☻ {ctx.author}')
		await ctx.send(embed=embed)

#--- METHODS ---#

@client.command()
@has_role("卐")
@commands.guild_only()
async def methods(ctx):
    await ctx.message.delete()
    embed = discord.Embed(color=reds, title="Boot.PY Methods Menu", timestamp=ctx.message.created_at)
    embed.add_field(name="Home Holder Methods", value=f"""```  
[5GBps] HOME
[1GBps] CLAP
[5GBps] NTP
[1GBps] DNS
[END ATK] STOP```""", inline=True)
    embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar_url)
    await ctx.send(embed=embed)

#--- API ---#

@client.command()
@has_role("卐")
@commands.cooldown(1,60, BucketType.user)
@commands.guild_only()
async def attack(ctx, host, port, time, method, pps):
    await ctx.message.delete()
    api = f"" ### <<< API LINK GOES HERE
    if host in blacklist:
        embed = discord.Embed(color=reds, title=f"{host} Is Blacklisted.")
        await ctx.send(embed=embed)
    elif host not in blacklist and has_role("卐"):
        embed = discord.Embed(color=reds, timestamp=ctx.message.created_at)
        embed.add_field(name="Host", value=f"{host}", inline=False)
        embed.add_field(name="Port", value=f"{port}", inline=False)
        embed.add_field(name="Time", value=f"{time}", inline=False)
        embed.add_field(name="Method", value=f"{method}", inline=False)
        embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/893798872202248232/893817597915697172/2644_earthblack.gif")
        embed.set_footer(text=f"Stress by {ctx.author}", icon_url=ctx.author.avatar_url)
        await ctx.send(embed=embed)
        response = requests.get(api)
        print(f"STRESS SUCCESSFUL Sent by {ctx.author} Target {host} using port {port} for {time} seconds\n")
        embed = discord.Embed(color=reds, title=f"{ctx.author} Your Cooldown has Started")
        print(f"[COOLDOWN STARTED] PLEASE WAIT FOR COOLDOWN TO FINISH {ctx.author}\n")
        await ctx.send(embed=embed)
        await asyncio.sleep(60)
        embed = discord.Embed(color=reds, title=f"CoolDown Complete for {ctx.author}")
        print(f"[COOLDOWN FINISHED] COOLDOWN FINISHED for {ctx.author}\n")
        await ctx.send(embed=embed)
    else:
        embed = discord.Embed(color=reds, title="Uh Oh..", description="""```
                Looks like there was an error...
                Here are some possible reasons for that error:```""", timestamp=ctx.message.created_at)
        embed.add_field(name="Syntax", value=f"{PREFIX}Attack IP 80 100 HOME", inline=False)
        embed.add_field(name="Missing Arguments", value="Check for missing arguments", inline=False)
        embed.add_field(name="Missing Plan", value="Make sure your plan is active ;status", inline=False)
        await ctx.send(embed=embed)

#--- PAPING ---#

@client.command()
@has_role("卐")
@commands.guild_only()
@commands.cooldown(1,5, BucketType.user)
async def paping(ctx, host, port):
        embed = discord.Embed (title=f"TCP Ping {host} on port {port}")
        await ctx.send(embed=embed)
        response = os.system(f"paping {host} -p {port} -c 3")
        if response == 0:
            embed = discord.Embed (title=f'Port {port} is open on {host}')
            await ctx.send(embed=embed)
        else:
            embed = discord.Embed (title=f'Port {port} is not open on {host}')
            await ctx.send(embed=embed)

#--- PORTSCAN ---#

@client.command()
@has_role("卐")
@commands.guild_only()
@commands.cooldown(1,5, BucketType.user)
async def pscan(ctx, host):
    await ctx.message.delete()
    embed = discord.Embed(color=reds, title=f"Scanning ||{host}||, requested by {ctx.author.display_name} please wait.")
    await ctx.send(embed=embed)
    await asyncio.sleep(0.5)
    embed = discord.Embed(color=reds, title=f"Scanning ||{host}|| on port:`22`(SSH)")
    await ctx.send(embed=embed)
    response = os.system(f"paping {host} -p 22 -c 3")
    if response == 0:
        embed = discord.Embed(color=0x2ecc71, title=f"Scanning Port `22` • `Open`")
        await ctx.send(embed=embed)
        await asyncio.sleep(0.5)
        embed = discord.Embed(color=reds, title=f"Scanning ||{host}|| on port:`23`(TELNET)")
        await ctx.send(embed=embed)
        response = os.system(f"paping {host} -p 23 -c 3")
    else:
        embed = discord.Embed(color=0xe74c3c, title=f"Scanning Port `22` • `Closed`")
        await ctx.send(embed=embed)
        await asyncio.sleep(0.5)
        embed = discord.Embed(color=reds, title=f"Scanning ||{host}|| on port:`23`(TELNET)")
        await ctx.send(embed=embed)
        response = os.system(f"paping {host} -p 23 -c 3")
    if response == 0:
        embed = discord.Embed(color=0x2ecc71, title=f"Scanning Port `23` • `Open`")
        await ctx.send(embed=embed)
        await asyncio.sleep(0.5)
        embed = discord.Embed(color=reds, title=f"Scanning ||{host}|| on port:`53`(DNS)")
        await ctx.send(embed=embed)
        response = os.system(f"paping {host} -p 53 -c 3")
    else:
        embed = discord.Embed(color=0xe74c3c, title=f"Scanning Port `23` • `Closed`")
        await ctx.send(embed=embed)
        await asyncio.sleep(0.5)
        embed = discord.Embed(color=reds, title=f"Scanning ||{host}|| on port:`53`(DNS)")
        await ctx.send(embed=embed)
        response = os.system(f"paping {host} -p 53 -c 3")
    if response == 0:
        embed = discord.Embed(color=0x2ecc71, title=f"Scanning Port `53` • `Open`")
        await ctx.send(embed=embed)
        await asyncio.sleep(0.5)
        embed = discord.Embed(color=reds, title=f"Scanning ||{host}|| on port:`80`(HTTP)")
        await ctx.send(embed=embed)
        response = os.system(f"paping {host} -p 80 -c 3")
    else:
        embed = discord.Embed(color=0xe74c3c, title=f"Scanning ||{host}|| • `Closed`")
        await ctx.send(embed=embed)
        await asyncio.sleep(0.5)
        embed = discord.Embed(color=reds, title=f"Scanning ||{host}|| on port:`80`(HTTP)")
        await ctx.send(embed=embed)
        response = os.system(f"paping {host} -p 80 -c 3")
    if response == 0:
        embed = discord.Embed(color=0x2ecc71, title=f"Scanning Port `80` • `Open`")
        await ctx.send(embed=embed)
        await asyncio.sleep(0.5)
        embed = discord.Embed(color=reds, title=f"Scanning ||{host}|| on port:`443`(HTTPS)")
        await ctx.send(embed=embed)
        response = os.system(f"paping {host} -p 443 -c 3")
    else:
        embed = discord.Embed(color=0xe74c3c, title=f"Scanning Port `80` • `Closed`")
        await ctx.send(embed=embed)
        await asyncio.sleep(0.5)
        embed = discord.Embed(color=reds, title=f"Scanning ||{host}|| on port:`443`(HTTPS)")
        await ctx.send(embed=embed)
        response = os.system(f"paping {host} -p 443 -c 3")
    if response == 0:
        embed = discord.Embed(color=0x2ecc71, title=f"Scanning Port `443` • `Open`")
        await ctx.send(embed=embed)
        await asyncio.sleep(0.5)
        embed = discord.Embed(color=reds, title=f"Scanning ||{host}|| on port:`65511`(COMMON TCP PORT)")
        await ctx.send(embed=embed)
        response = os.system(f"paping {host} -p 65511 -c 3")
    else:
        embed = discord.Embed(color=0xe74c3c, title=f"Scanning Port `443` • `Closed`")
        await ctx.send(embed=embed)
        await asyncio.sleep(0.5)
        embed = discord.Embed(color=reds, title=f"Scanning ||{host}|| on port:`65511`(COMMON TCP PORT)")
        await ctx.send(embed=embed)
        response = os.system(f"paping {host} -p 65511 -c 3")
    if response == 0:
        embed = discord.Embed(color=0xe74c3c, title=f"Scanning Port `65511` • `Closed`")
        await ctx.send(embed=embed)
        await asyncio.sleep(0.5)
        embed = discord.Embed(color=reds, title=f"Scanning ||{host}|| complete!")
        await ctx.send(embed=embed)
    else:
        embed = discord.Embed(color=0xe74c3c, title=f"Scanning Port `65511` • `Closed`")
        await ctx.send(embed=embed)
        await asyncio.sleep(0.5)
        embed = discord.Embed(color=reds, title=f"Scanning ||{host}|| complete!")
        await ctx.send(embed=embed)
@pscan.error
async def scan_error(ctx, error):
    if isinstance(error, commands.CheckFailure):
            embed = discord.Embed(color=0x3498db, title="Uh Oh..", description="""```
            Looks like there was an error...
            Here are some possible reasons for the error.```""")
            embed.add_field(name="Syntax", value="//scan host", inline=False)
            embed.add_field(name="Missing Arguments", value="Check for missing arguments", inline=False)
            await ctx.send(embed=embed)

#--- MOD HELP COMMANDS ---#

# Add Role

@client.command()
@commands.has_permissions(manage_roles=True)
async def add(ctx, role: discord.Role, user: discord.Member):
  await ctx.message.delete()
  embed = discord.Embed(title="***Boot.PY***",description=f'***Successfully Given {role.mention} to {user.mention}.***', color=000000)
  print(f"[Add Role SUCCESS] Role Added by {ctx.author} Role Given {role.mention} User Whom Received Role {user.mention}\n")
  embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar_url)
  embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/893798872202248232/893817597915697172/2644_earthblack.gif")
  await user.add_roles(role)
  await ctx.send(embed=embed)


# Ban User

@client.command()
@commands.has_permissions(ban_members=True)
async def ban(ctx, member : discord.Member, *, reason=None):
  await ctx.message.delete()
  embed = discord.Embed(title="***Boot.PY***",description=f'***User {member.mention} Has Been Banned.***', color=000000)
  embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar_url)
  embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/893798872202248232/893817597915697172/2644_earthblack.gif")
  await member.ban(reason=reason)
  await ctx.send(embed=embed)


# Clear Chat

@client.command()
@commands.has_permissions(manage_messages=True)
async def clear(ctx, amount=100):
  await ctx.message.delete()
  embed = discord.Embed(title="***Boot.PY***",description=f'***Successfully Cleared {amount} Messages.***', color=000000)
  embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar_url)
  embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/893798872202248232/893817597915697172/2644_earthblack.gif")
  await ctx.channel.purge(limit=amount)
  await ctx.send(embed=embed)

# Mute User

@client.command()
@commands.has_permissions(manage_messages=True)
async def mute(ctx, member: discord.Member, *, reason=None):
    await ctx.message.delete()
    embed = discord.Embed(title="***Boot.PY***",description=f'***Successfully Muted {member.mention} {reason}.***', color=000000)
    embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar_url)
    embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/893798872202248232/893817597915697172/2644_earthblack.gif")
    guild = ctx.guild
    mutedRole = discord.utils.get(guild.roles, name="Muted")
    onyxRole = discord.utils.get(guild.roles, name="Verified")

    if not mutedRole:
        mutedRole = await guild.create_role(name="Muted")

        for channel in guild.channels:
            await channel.set_permissions(mutedRole, speak=False, send_messages=False, read_messages=True, view_channel=True)

    await member.add_roles(mutedRole, reason=reason)
    await member.remove_roles(onyxRole, reason=reason)
    await ctx.send(embed=embed)
    await member.send(f"***You Were Muted In The Server {ctx.guild.name} For the Reason {reason}***")

# Kick

@client.command()
@commands.has_permissions(kick_members=True)
async def kick(ctx, member : discord.Member, *, reason=None):
  await ctx.message.delete()
  embed = discord.Embed(title="***Boot.PY***",description=f'***User @{member} Has Been Kicked For {reason} ***', color=000000)
  embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar_url)
  embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/893798872202248232/893817597915697172/2644_earthblack.gif")
  await member.kick(reason=reason)
  await ctx.send(embed=embed)
  await member.send(f"***You Were Kicked From The Server {ctx.guild.name} For the Reason {reason}***")
  await ctx.send(embed=embed)

# Nuke

@client.command()
@commands.has_permissions(manage_messages=True)
async def nuke(ctx):
    await ctx.channel.purge(limit=10000)
    embed = discord.Embed(title="***Boot.PY***",description=f'***Successfully Nuked This Channel***', color=000000)
    embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar_url)
    embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/893798872202248232/893817597915697172/2644_earthblack.gif")
    await ctx.send(embed=embed)

# Remove Role

@client.command()
@commands.has_permissions(manage_roles=True)
async def remove(ctx, role: discord.Role, user: discord.Member):
  await ctx.message.delete()
  embed = discord.Embed(title="***Boot.PY***",description=f'***Successfully Removed {role.mention} From {user.mention}.***', color=000000)
  embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar_url)
  embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/893798872202248232/893817597915697172/2644_earthblack.gif")
  await user.remove_roles(role)
  await ctx.send(embed=embed)

# UnMute User

@client.command()
@commands.has_permissions(manage_messages=True)
async def unmute(ctx, *, member: discord.Member):
    await ctx.message.delete()
    embed = discord.Embed(title="***Boot.PY***",description=f'***Successfully Unmuted {member.mention} From {ctx.guild.name}.***', color=000000)
    embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar_url)
    embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/893798872202248232/893817597915697172/2644_earthblack.gif")
    mutedRole = discord.utils.get(ctx.guild.roles, name="Muted")
    onyxRole = discord.utils.get(ctx.guild.roles, name="Verified")

    await member.add_roles(memberRole)
    await member.remove_roles(mutedRole)
    await ctx.send(embed=embed)
    await member.send(f"You Were Unmuted In The Server {ctx.guild.name}")
    client.run(TOKEN)

#--- END OF CODE ---#